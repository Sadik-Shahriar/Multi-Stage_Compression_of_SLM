# PyramidKV validation on LongBench v1 TREC

All 200 TREC examples used identical token IDs, a single pinned Llama 3.2-3B-Instruct
AWQ checkpoint, greedy decoding, and a 4,096-token prompt cap.
Each eviction implementation used nominal K=1,024. Cache settings and head layouts
follow each implementation. Counts below refer to the prefill cache and exclude decode tokens.

| Configuration | TREC score (%) | Mean tokens per layer | Mean head-token slots across layers |
|---|---:|---:|---:|
| FullKV (upstream environment) | 67.50 | 3848.5 | 862057 |
| Authors’ PyramidKV | 65.50 | 1031.4 | 693092 |
| FullKV (custom environment) | 68.00 | 3848.5 | 862057 |
| Paper’s custom PyramidKV-style eviction | 65.50 | 1024.0 | 229371 |

| Paired contrast | Difference (pp) | 95% paired bootstrap CI (pp) |
|---|---:|---:|
| Authors’ PyramidKV minus its FullKV | -2.00 | [-4.50, +0.00] |
| Custom eviction minus its FullKV | -2.50 | [-5.00, -0.50] |
| Custom eviction minus authors’ PyramidKV | +0.00 | [-2.00, +2.00] |
| Custom FullKV minus upstream FullKV | +0.50 | [+0.00, +1.50] |
| Difference in changes from each FullKV (custom minus upstream) | -0.50 | [-2.50, +1.00] |

Stock FullKV generated identical token sequences on 185 of 200 cases and had identical per-case scores on 199 cases.

The upstream path used Transformers 4.44.2 and PyTorch 2.11.0+cu128. The custom path used Transformers 5.12.1 and PyTorch 2.11.0+cu128. The two FullKV controls measure baseline agreement across software environments. Differences can still reflect how eviction interacts with the software stack. This comparison establishes the observed score gap on the 3B TREC setup. Reproducing the published Llama-3-8B scores requires the published setup.
