# Same-session Llama wrapper control and energy interaction

We measured all five conditions in 10 counterbalanced blocks on one NVIDIA T4 at an enforced board power limit of 70 W, using the same resident AWQ checkpoint, 4,096-token prompt, and 64 teacher-forced decode tokens. Both AWQ energy baselines had cache compression disabled. The stock/wrapped parity probe passed. Energy is raw GPU-board joules integrated over prefill and decode.

- Stock AWQ C1 mean ± SD: 579.26 ± 5.03 J.
- Wrapped AWQ C1-W mean ± SD: 575.13 ± 16.71 J.
- Wrapped minus stock baseline is -4.13 J (95% paired CI [-16.36, +8.10] J, includes zero), or -0.71% of the stock mean.
- Interaction using stock C1 is -212.41 J (95% paired CI [-226.65, -198.16] J, excludes zero).
- Interaction using wrapped C1-W is -216.54 J (95% paired CI [-237.15, -195.92] J, excludes zero).

Substituting the wrapped baseline shifts the mean interaction by -4.13 J. The interaction estimate stayed negative with either baseline. These intervals describe repeated blocks on the tested workload and session. The experiment quantifies the energy effect of the tested wrapper configuration. Published PyramidKV accuracy is outside this test.
